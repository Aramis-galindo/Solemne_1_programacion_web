from django import forms
from django.forms import ModelForm
from .models import Plan
import datetime
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class PlanForm(ModelForm):  
    class Meta:
        model = Plan
        fields = ['nombre','descripcion','precio','fecha_apertura','genero']



        widgets = {
            'fecha_apertura': forms.SelectDateWidget(years=range(2021,2022,2023))
        }

        
    def clean_fecha_apertura(self):
        fecha = self.cleaned_data['fecha_apertura']
        if fecha > datetime.date.today():
            raise forms.ValidationError("La fecha no puede ser mayor a la fecha de hoy")

        return fecha

class CustomUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['first_name','last_name','email','username','password1','password2'] 
    pass
