from django.urls import path
from .views import index, catalogo, planes, conectividad ,agregar,modificar,listado,eliminar,registro_usuario


urlpatterns = [
    path('',index, name="index"),
    path('catalogo/',catalogo, name="catalogo"),
    path('planes/',planes, name="planes"),
    path('conectividad/',conectividad, name="conectividad"),
    path('agregar/',agregar, name="agregar"),
    path('modificar/<id>/',modificar, name="modificar"),
    path('listado/',listado, name="listado"),
    path('eliminar/<id>/',eliminar, name="eliminar"),
    path('registro/', registro_usuario, name="registro_usuario"),
]

