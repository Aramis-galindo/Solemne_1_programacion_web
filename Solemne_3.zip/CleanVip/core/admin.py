from django.contrib import admin
from .models import Genero
from .models import Plan

# Register your models here.
class PlanAdmin(admin.ModelAdmin):
    list_display = ['nombre','descripcion','precio', 'fecha_apertura', 'genero']
    search_fields = ['nombre','precio']
    list_filter = ['genero']
    list_per_page = 4

admin.site.register(Genero)
admin.site.register(Plan,PlanAdmin)