from django.db import models
from django.db.models.deletion import CASCADE

# Create your models here.


class Genero(models.Model):
    nombre = models.CharField(max_length=80)

    def __str__(self):
        return self.nombre

class Plan(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField(null= True, blank=True)
    precio = models.IntegerField()
    fecha_apertura = models.DateField()
    genero = models.ForeignKey(Genero, on_delete=CASCADE)

    def __str__(self):
        return self.nombre