$(document).ready(function () {
    // ocultar el div#error
    $("#error").hide();

    $("#Identificacion").hide();
    $(".iden").click(function () {
        $("#Identificacion").show();
    });

    // agregar la validacion al formulario cuando haga submit
    $("#formulario").submit(function () {
        var mensajeGeneral = "";
        mensajeNombre = "";
        mensajeCorreo = "";
        mensajeRut = "";
        mensajeComentario = "";


        // validar que el nombre no este vacio
        if ($("#nombre").val().trim().length == 0) {
            mensajeNombre = "El nombre esta en blanco</br>";
            //alert(mensaje);
        }

        // cuando se presione una tacla desde el nombre borre el mensaje de error
        $("#nombre").keypress(function () {
            mensajeNombre = "";
            mensajeGeneral = mensajeNombre;
            $("#error").hide(mensajeGeneral);
            if (mensajeGeneral == "") {
                $("#error").hide();
            }
        });

        if ($("#email").val().trim().length == 0) {
            mensajeCorreo = "El email esta en blanco</br>";
        }

        $("#email").keypress(function () {
            mensajeCorreo = "";
            mensajeGeneral = mensajeNombre + mensajeCorreo;
            $("#error").hide(mensajeGeneral);
            if (mensajeGeneral == "") {
                $("#error").hide();
            }
        });

        let Rut = $("#Identificacion").val().trim();    
            if (!isValidRUT(Rut)) {
                mensajeRut = "El RUT no es valido</br>";
            }


        $("#Identificacion").keypress(function () {
            mensajeRut = "";
            mensajeGeneral = mensajeNombre + mensajeCorreo + mensajeRut;
            $("#error").hide(mensajeGeneral);
            if (mensajeGeneral == "") {
                $("#error").hide();
            }
        });
        if ($("#Comentario").val().trim().length < 50) {
            mensajeComentario = "El Comentario como mínimo 50 caracteres";
        }

        $("#Comentario").keypress(function () {
            mensajeComentario = "";
            mensajeGeneral = mensajeNombre + mensajeCorreo + mensajeRut + mensajeComentario;
            $("#error").hide(mensajeGeneral);
            if (mensajeGeneral == "") {
                $("#error").hide();
            }
        });
        mensajeGeneral = mensajeNombre + mensajeCorreo + mensajeRut + mensajeComentario;
        // preguntar si hay error
        if (mensajeGeneral != "") {
            $("#error").html(mensajeGeneral);
            $("#error").show();
            // anulamos el envio de datos
            event.preventDefault();
        }

        $("#limpiar").click(function () {
            $("#Identificacion").hide();
            $("#error").hide();
        });

    });
})

function isValidRUT(Rut) {

    let regexp = new RegExp(/^\d{8}-[k|K|\d]{1}$/);
    return regexp.test(Rut);
}