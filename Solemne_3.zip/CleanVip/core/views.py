from django.shortcuts import render, redirect
from .models import Plan
from .forms import PlanForm
from .forms import CustomUserForm
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import authenticate, login

# Create your views here.

def index(request):
    return render(request,'core/index.html')


def catalogo(request):
    return render(request,'core/Catalogo.html')

@login_required
def planes(request):
    return render(request,'core/planes.html')

@login_required
def conectividad(request):
    return render(request,'core/conectividad.html')

@permission_required('core.add_plan')
def agregar(request):

    data={
        'form': PlanForm()
    }
    if request.method == 'POST':
        formulario = PlanForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            data['mensaje'] = "Guardado correctamente"
        data['form'] = formulario

    return render(request,'core/agregar.html',data)

@permission_required('core.change_plan')
def modificar(request,id):

    plan = Plan.objects.get(id = id)
    data = {
        'form': PlanForm(instance = plan)
    }
    if request.method == 'POST':
        formulario = PlanForm(data = request.POST, instance=plan)
        if formulario.is_valid():
            formulario.save()
            data['mensaje']= "Plan Modificada correctamente"
        data['form']= formulario

    return render(request,'core/modificar.html',data)

@permission_required('core.delete_plan')
def eliminar(request,id):
    plan = Plan.objects.get(id = id)
    plan.delete()

    return redirect(to = "listado")

def listado(request):
    planes= Plan.objects.all()
    data={
        'planes': planes
    }
    return render(request,'core/listado.html',data)

def registro_usuario(request):
    data = {
        'form':CustomUserForm()
    }
    if request.method == 'POST':
        formulario = CustomUserForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            username = formulario.cleaned_data['username']
            password = formulario.cleaned_data['password1']
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect(to='index')

    return render(request, "registration/registrar.html",data)

