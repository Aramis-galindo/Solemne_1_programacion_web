
$(document).ready(function () {
    $("#enviar").click(function () {

        $.get("https://mindicador.cl/api/dolar",
            function (data) {

                $.each(data.serie,
                    function (i, item) {

                        $("#categorias").append(
                            "<tr>" +
                            "<td>"+ "Dolar" +
                            "</td>"+
                            "<td>" + item.fecha + 
                            "</td>" +
                            "<td>" + item.valor + 
                            "</td>" +     
                            "</tr>"
                        );
                    })
            }
        )
    })
    $("#enviar2").click(function () {

        $.get("https://mindicador.cl/api/euro",
            function (data) {

                $.each(data.serie,
                    function (i, item) {

                        $("#categorias").append(
                            "<tr>" +
                            "<td>"+ "Euro" +
                            "</td>"+
                            "<td>" + item.fecha + 
                            "</td>" +
                            "<td>" + item.valor + 
                            "</td>" +        
                            "</tr>"
                        );
                    })
            }
        )
    })
    $("#enviar3").click(function () {

        $.get("https://mindicador.cl/api/uf",
            function (data) {

                $.each(data.serie,
                    function (i, item) {

                        $("#categorias").append(
                            "<tr>" +
                            "<td>"+ "UF" +
                            "</td>"+
                            "<td>" + item.fecha + 
                            "</td>" +
                            "<td>" + item.valor + 
                            "</td>" +        
                            "</tr>"
                        );
                    })
            }
        )

        
    })
    $("#enviar4").click(function () {

        $.get("https://mindicador.cl/api/bitcoin",
            function (data) {

                $.each(data.serie,
                    function (i, item) {

                        $("#categorias").append(
                            "<tr>" +
                            "<td>"+ "Bitcoin" +
                            "</td>"+
                            "<td>" + item.fecha + 
                            "</td>" +
                            "<td>" + item.valor + 
                            "</td>" +        
                            "</tr>"
                        );
                    })
            }
        )
    })
    $("#enviar5").click(function () {

        $.get("https://mindicador.cl/api/utm",
            function (data) {

                $.each(data.serie,
                    function (i, item) {

                        $("#categorias").append(
                            "<tr>" +
                            "<td>"+ "UTM" +
                            "</td>"+
                            "<td>" + item.fecha + 
                            "</td>" +
                            "<td>" + item.valor + 
                            "</td>" +        
                            "</tr>"
                        );
                    })
            }
        )
    })


    $("#borrar").click(function () {
        $("#datos_tabla").empty();
    })
    
    
})